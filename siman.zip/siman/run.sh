java -jar samurAI2016.jar
